from collections import defaultdict

from homr.transformer.vocabulary import EncodedSymbol


class EncodedSymbolWithPos:
    def __init__(
        self,
        position: int,
        symbol: EncodedSymbol,
        insert_before: bool = False,
        grace_index: int = 0,
    ) -> None:
        self.position = position
        self.symbol = symbol
        self.rhythm = symbol.rhythm
        self.insert_before = insert_before
        # Grace notes take no time, so several of them before the same note share a position.
        # The index keeps them in order.
        self.grace_index = grace_index

    def sort_order(self) -> tuple[int, int]:
        return (self.position * 2 - (1 if self.insert_before else 0), self.grace_index)

    def __str__(self) -> str:
        return str(self.position) + " " + str(self.symbol)

    def __repr__(self) -> str:
        return str(self)


def merge_upper_and_lower_staff(voices: list[list[EncodedSymbolWithPos]]) -> list[EncodedSymbol]:
    voices = [voice for voice in voices if len(voice) > 0]
    positions: defaultdict[tuple[int, int], list[EncodedSymbol]] = defaultdict(list)
    for voice in voices:
        for symbol in voice:
            positions[symbol.sort_order()].append(symbol.symbol)

    result: list[EncodedSymbol] = []
    for key in sorted(positions):
        result.extend(create_chord_over_two_staffs(positions[key]))

    if (
        len(result) > 0
        and "barline" not in result[-1].rhythm
        and not result[-1].rhythm.startswith("repeat")
    ):
        result.append(EncodedSymbol("barline"))
    if len(result) > 0 and result[-1].rhythm == "repeatEndStart":
        result.pop()
        result.append(EncodedSymbol("repeatEnd"))
    return result


def create_chord_over_two_staffs(symbols: list[EncodedSymbol]) -> list[EncodedSymbol]:
    barlines = []
    key = []
    time = []
    clef = []
    notes_or_rests = []
    for symbol in symbols:
        rhythm = symbol.rhythm
        if "barline" in rhythm or "repeat" in rhythm:
            if symbol not in barlines:
                barlines.append(symbol)
        elif rhythm.startswith("keySignature"):
            if symbol not in key:
                key.append(symbol)
        elif rhythm.startswith("timeSignature"):
            if symbol not in time:
                time.append(symbol)
        elif rhythm.startswith("clef"):
            clef.append(symbol)
        else:
            notes_or_rests.append(symbol)
    result = []
    result.extend(barlines)
    for i, symbol in enumerate(clef):
        is_first = i == 0
        if not is_first:
            result.append(EncodedSymbol("chord"))
        result.append(symbol)
    result.extend(key)
    result.extend(time)

    for i, symbol in enumerate(notes_or_rests):
        is_first = i == 0
        if not is_first:
            result.append(EncodedSymbol("chord"))
        result.append(symbol)
    return result
