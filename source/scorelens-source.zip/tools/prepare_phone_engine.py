"""Stage the pinned browser OMR engine, model weights, and corresponding source."""

import argparse
from base64 import b64encode
from hashlib import file_digest
import json
from pathlib import Path
import shutil
import tarfile
from tempfile import TemporaryDirectory
from urllib.request import Request, urlopen
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "static/scanner-pack/engine"
PARTSONG = "d1bf4778b3b30f3e3915777abdd72e732bd59330"
HOMR_RS = "f6309104e3582bae8df22669f0325e7fd1a7ab32"
HOMR = "0dd86956b15982c4e388029054920ce655a13886"
ORT = "1.30.0"
MODELS = {
    "segnet_308-3296ccd40960f90ca6ab9c035cca945675d30a0f": (
        57311361, "6ed36640db4ef5d223098b6d5efe4eda97c66b24a2c72faab8a018c749003a8d",
    ),
    "encoder_pytorch_model_509-2293bba14bfea47d9d28411339362af15fce4c31": (
        52861122, "ee5767286c60dc3d567fe72b6560e7285261ede1535b4215153c199ab3057559",
    ),
    "decoder_pytorch_model_509-2293bba14bfea47d9d28411339362af15fce4c31": (
        47356003, "99a6ac39770616bc1a20d6c409bb85fbbe21ba47f972984f9ef834fb5741b96f",
    ),
}
ORT_FILES = {
    "ort.webgpu.min.mjs",
    "ort-wasm-simd-threaded.asyncify.mjs",
    "ort-wasm-simd-threaded.asyncify.wasm",
}
PARTSONG_FILES = {
    "omr-worker.js",
    "omr/encoder_gpu.mjs",
    "omr/encoder_gpu_kernels.mjs",
    "omr/encoder_gpu_math.mjs",
    "omr/encoder_pool.mjs",
    "omr/encoder_worker.mjs",
    "omr/partsong_omr.wasm",
    "omr/partsong_omr_fused.wasm",
    "omr/partsong_omr_threads.wasm",
    "omr/partsong_omr_threads_fused.wasm",
}
UPSTREAM_ZIPS = {
    "partsong-source.zip": (
        f"https://codeload.github.com/pzfreo/partsong/zip/{PARTSONG}",
        "a34ae152bd18b7fe9306698971093b706cb71bf6ddbfd134f0a95db36fc5b7da",
    ),
    "homr-rs-source.zip": (
        f"https://codeload.github.com/pzfreo/homr-rs/zip/{HOMR_RS}",
        "837781ca761e57dbd20263f4a2eb9bbec85d619621010f746505bdcc9aedc8a2",
    ),
    "homr-0.7.1-source.zip": (
        f"https://codeload.github.com/liebharc/homr/zip/{HOMR}",
        "5ecbb53c8b7234352161b3899e4b17722d620715358205309aaea82b3b512787",
    ),
}
ORT_NOTICES = {
    "ort-1.30-license.txt": (
        "LICENSE", "2f07c72751aed99790b8a4869cf2311df85a860b22ded05fa22803587a48922c",
    ),
    "ort-1.30-notices.txt": (
        "ThirdPartyNotices.txt", "143764b952fdb1a7c69ce653bfba74a7744d6a8a573bfb73e235fba356c83de3",
    ),
}


def digest(path, algorithm="sha256"):
    with path.open("rb") as file:
        return file_digest(file, algorithm).digest()


def download(cache, name, url, valid):
    path = cache / name
    if path.is_file() and valid(path):
        return path
    partial = path.with_suffix(path.suffix + ".part")
    for _ in range(3):
        try:
            with urlopen(Request(url, headers={"User-Agent": "ScoreLens asset preparation"}), timeout=120) as response:
                with partial.open("wb") as target:
                    shutil.copyfileobj(response, target, length=1024 * 1024)
            if not valid(partial):
                raise ValueError(f"Checksum mismatch for {name}.")
            partial.replace(path)
            return path
        except OSError as error:
            last_error = error
        finally:
            partial.unlink(missing_ok=True)
    raise OSError(f"Could not download {name}: {last_error}")


def checked_download(cache, name, url, expected):
    return download(cache, name, url, lambda path: digest(path).hex() == expected)


def write_pack_file(output, filename, data):
    target = output / filename
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def adapt_worker(original):
    """Use the site service worker as the only persistent model cache."""
    source = original.decode("utf-8")
    start = source.index("// Models download in 4 MB pieces")
    retry = source.index("const sleep = (ms)", start)
    fetch = source.index("async function fetchPiece(", retry)
    end = source.index("// On iPhones and iPads, segnet", fetch)
    sizes = json.dumps({name + ".onnx": size for name, (size, _) in MODELS.items()}, indent=2)
    fetch_weights = """
// ScoreLens owns the offline cache. Read its same-origin response straight
// into the target array so a phone need not hold a second complete model.
async function modelBytes(name, into = (size) => new Uint8Array(size)) {
  const response = await fetch(new URL("models/" + name, import.meta.url), { redirect: "error" });
  if (!response.ok || !response.body) {
    throw new Error("The scanner model is unavailable. Download the scanner pack again.");
  }
  const size = MODEL_SIZES[name];
  const bytes = into(size);
  const reader = response.body.getReader();
  let offset = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (offset + value.byteLength > size) throw new Error("The scanner model has the wrong size.");
      bytes.set(value, offset);
      offset += value.byteLength;
    }
  } finally {
    await reader.cancel().catch(() => {});
  }
  if (offset !== size) throw new Error("The scanner model download is incomplete.");
  return bytes;
}

"""
    source = (
        source[:start]
        + f"const MODEL_SIZES = {sizes};\n"
        + source[retry:fetch]
        + fetch_weights
        + source[end:]
    )
    source = source.replace('const MODEL_CACHE = "partscanner-models-v1";\n', "")
    source = source.replace(
        "// Uncompressed total, for progress: servers may gzip, so content-length\n"
        "// doesn't match the bytes received.\nconst MODELS_TOTAL_BYTES = 157528486;\n",
        "",
    )
    source = source.replace("modelBytes(MODELS[2], false,", "modelBytes(MODELS[2],")
    source = source.replace("modelBytes(MODELS[1], false,", "modelBytes(MODELS[1],")
    source = source.replace(
        "  for (const name of MODELS) {\n    await downloadModel(name);\n  }\n  await dropOldModels();\n",
        "",
    )
    source = source.replace(
        "async function pixels(bytes) {\n",
        """async function pixels(bytes) {
  // Older WebKit workers can receive pixels transferred from a DOM canvas.
  if (bytes?.data instanceof Uint8ClampedArray &&
      Number.isSafeInteger(bytes.width) && bytes.width > 0 &&
      Number.isSafeInteger(bytes.height) && bytes.height > 0 &&
      bytes.data.length === bytes.width * bytes.height * 4) {
    return bytes;
  }
""",
    )
    source = source.replace(
        '  post({ type: "ready", gpu: useGpu });',
        """  let needsPixels = true;
  try {
    needsPixels = typeof createImageBitmap !== "function" ||
      !new OffscreenCanvas(1, 1).getContext("2d");
  } catch {}
  post({ type: "ready", gpu: useGpu, needsPixels });""",
    )
    assert "caches.open" not in source and "downloadModel(" not in source
    notice = f"""// Derived from Partsong {PARTSONG} (AGPL-3.0-only).
// ScoreLens changes: stream same-origin weights from the site's offline cache.
// Accept transferable pixels from browsers without a worker canvas.
// Corresponding source and licenses are in this engine's source directory.
"""
    return (notice + source).encode("utf-8")


def stage_runtime(cache, output, partsong_archive):
    with ZipFile(partsong_archive) as package:
        prefix = f"partsong-{PARTSONG}/"
        for filename in sorted(PARTSONG_FILES):
            contents = package.read(prefix + filename)
            if filename == "omr-worker.js":
                contents = adapt_worker(contents)
            write_pack_file(output, filename, contents)
        write_pack_file(output, "LICENSE-AGPL-3.0.txt", package.read(prefix + "LICENSE"))

    archive = download(
        cache, f"ort-web-{ORT}.tgz", f"https://registry.npmjs.org/onnxruntime-web/-/onnxruntime-web-{ORT}.tgz",
        lambda path: b64encode(digest(path, "sha512")).decode("ascii")
        == "q0y+JrrtukXSzsBWEMccVfqX25LRmosXHF+CaRJmg8pZClzcV7svNc4rKY3jL02Vb7QmRMDs1SigqR4CXAfKYQ==",
    )
    with tarfile.open(archive, "r:gz") as package:
        for filename in sorted(ORT_FILES):
            with package.extractfile("package/dist/" + filename) as file:
                write_pack_file(output, f"lib/onnxruntime-web@{ORT}/dist/{filename}", file.read())


def stage_models(cache, output, local_models):
    model_root = output / "models"
    model_root.mkdir(parents=True, exist_ok=True)
    for name, (size, checksum) in MODELS.items():
        filename = name + ".onnx"
        destination = model_root / filename

        def valid(file):
            return file.stat().st_size == size and digest(file).hex() == checksum

        if destination.is_file() and valid(destination):
            continue
        local = next(local_models.rglob(filename), None) if local_models else None
        partial = destination.with_suffix(".part")
        try:
            if local is not None:
                shutil.copyfile(local, partial)
            else:
                release = "https://github.com/liebharc/homr/releases/download/onnx_checkpoints"
                archive = download(cache, name + ".zip", f"{release}/{name}.zip", lambda path: path.stat().st_size > 1024)
                with ZipFile(archive) as package:
                    matches = [entry for entry in package.infolist()
                               if Path(entry.filename).name == filename and entry.file_size == size]
                    if len(matches) != 1:
                        raise ValueError(f"Model {filename} missing from its release archive.")
                    with package.open(matches[0]) as source, partial.open("wb") as target:
                        shutil.copyfileobj(source, target, length=1024 * 1024)
            if not valid(partial):
                raise ValueError(f"Model checksum mismatch for {filename}.")
            partial.replace(destination)
        finally:
            partial.unlink(missing_ok=True)


def add_source(archive, path, data):
    info = ZipInfo(path)
    info.compress_type = ZIP_DEFLATED
    archive.writestr(info, data)


def stage_source(cache, output, partsong_archive):
    for name, (url, checksum) in UPSTREAM_ZIPS.items():
        if name != "partsong-source.zip":
            original = checked_download(cache, name, url, checksum)
            (output / "source").mkdir(exist_ok=True)
            shutil.copyfile(original, output / "source" / name)
    for name, (filename, checksum) in ORT_NOTICES.items():
        url = f"https://cdn.jsdelivr.net/gh/microsoft/onnxruntime@v{ORT}/{filename}"
        original = checked_download(cache, name, url, checksum)
        write_pack_file(output, f"source/onnxruntime-{filename}", original.read_bytes())

    with ZipFile(partsong_archive) as upstream, ZipFile(output / "source/scorelens-omr-worker.zip", "w") as archive:
        for entry in upstream.infolist():
            path = entry.filename.partition("/")[2]
            if entry.is_dir() or not (
                path.startswith("omr-rs/") or path in {
                    "LICENSE", "README.md", "omr-worker.js",
                    "scripts/build-omr.sh", "scripts/fetch-models.sh", "scripts/fetch-libs.sh",
                } or (path.startswith("omr/") and path.endswith(".mjs"))
            ):
                continue
            add_source(archive, "upstream/" + path, upstream.read(entry))
        add_source(archive, "scorelens/omr-worker.js", (output / "omr-worker.js").read_bytes())
        add_source(archive, "scorelens/prepare_phone_engine.py", Path(__file__).read_bytes())

    notice = f"""ScoreLens on-device OMR engine

Licensed components
  Partsong worker and WebAssembly: AGPL-3.0-only.
  homr-rs and homr ONNX models: AGPL-3.0.
  ONNX Runtime Web: MIT. See source/onnxruntime-LICENSE and
    source/onnxruntime-ThirdPartyNotices.txt for notices.

Corresponding source
  scorelens-omr-worker.zip contains the adapted worker, generator, and
    original Partsong engine sources and build scripts ({PARTSONG}).
  homr-rs-source.zip is the dependency source at {HOMR_RS}.
  homr-0.7.1-source.zip includes the model architecture and training code
    from homr v0.7.1 ({HOMR}).
  ONNX Runtime Web {ORT} source: https://github.com/microsoft/onnxruntime/tree/v{ORT}
    Build: https://onnxruntime.ai/docs/build/web.html
  Run the upstream scripts/build-omr.sh from its extracted project,
    with the upstream omr-rs directory, Rust and the wasm32-unknown-unknown
    target. The script documents the nightly std tools for threaded builds.
  Run ScoreLens tools/prepare_phone_engine.py to reconstruct this browser
    engine from verified published assets or an existing local model cache.

Sources
  https://github.com/pzfreo/partsong/tree/{PARTSONG}
  https://github.com/pzfreo/homr-rs/tree/{HOMR_RS}
  https://github.com/liebharc/homr/tree/{HOMR}
"""
    write_pack_file(output, "source/NOTICE.txt", notice.encode("utf-8"))


def stage(cache, output, local_models):
    cache.mkdir(parents=True, exist_ok=True)
    output.mkdir(parents=True, exist_ok=True)
    name = "partsong-source.zip"
    partsong_archive = checked_download(cache, name, *UPSTREAM_ZIPS[name])
    stage_runtime(cache, output, partsong_archive)
    stage_models(cache, output, local_models)
    stage_source(cache, output, partsong_archive)
    paths = sorted(PARTSONG_FILES | {f"lib/onnxruntime-web@{ORT}/dist/{name}" for name in ORT_FILES}
                   | {f"models/{name}.onnx" for name in MODELS})
    entries = [
        {"path": path, "bytes": (output / path).stat().st_size, "sha256": digest(output / path).hex()}
        for path in paths
    ]
    write_pack_file(output, "runtime-assets.json", (json.dumps(entries, indent=2) + "\n").encode("utf-8"))
    print(f"Prepared {len(entries)} browser OMR assets, {sum(item['bytes'] for item in entries):,} bytes.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache-dir", type=Path, help="Reuse downloaded release archives.")
    parser.add_argument("--models-dir", type=Path, help="Reuse existing homr ONNX files after checksum verification.")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    if args.cache_dir:
        stage(args.cache_dir, args.output, args.models_dir)
    else:
        with TemporaryDirectory(prefix="scorelens-omr-") as cache:
            stage(Path(cache), args.output, args.models_dir)


if __name__ == "__main__":
    main()
