"""Build the static, subpath-safe phone distribution from staged scanner assets."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
from zipfile import ZipFile, ZIP_DEFLATED


ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "static"
PHONE = ROOT / "phone"
SHELL = (
    "app.js", "capture.js", "device-scan.js", "example.json", "follow.css", "follow.js",
    "grain.png", "icon-192.png", "icon-512.png", "icons.js", "key-reading.js",
    "keys.js", "listen.js", "morning-walk.png", "pdf-library.js", "practice.js",
    "score-conversion.js", "style.css", "teacher.js",
)


def public_files(directory):
    return sorted(p for p in directory.rglob("*") if p.is_file()
                  and not any(s.startswith(".") or s == "__pycache__" for s in p.relative_to(directory).parts))


def digest(data):
    return sha256(data).hexdigest()


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError(f"Phone template does not match: {before}")
    return text.replace(before, after)


def is_notice(path):
    return ("LICENSE" in path.name.upper() or "NOTICE" in path.name.upper() or
            "THIRD-PARTY" in path.name.upper() or path.suffix.lower() == ".md")


def build(out):
    # Always build into a fresh directory so a previous deployment cannot leak into it.
    if out.exists() and any(out.iterdir()):
        raise ValueError("Choose an empty build directory.")
    out.mkdir(parents=True, exist_ok=True)
    pack = STATIC / "scanner-pack"
    for component in ("converter", "engine", "pdf"):
        if not (pack / component).is_dir():
            raise ValueError(f"Prepare the {component} scanner component first.")
    assets = public_files(pack)
    inventory = [dict(path=p.relative_to(pack).as_posix(), bytes=p.stat().st_size,
                      sha256=digest(p.read_bytes())) for p in assets
                 if not is_notice(p) and "source" not in p.relative_to(pack).parts]
    pack_id = digest(json.dumps(inventory).encode())[:16]
    pack_path = "packs/" + pack_id
    for p in assets:
        dest = out / pack_path / p.relative_to(pack)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)

    files = {name: (STATIC / name).read_bytes() for name in SHELL}
    for group in ("fonts", "scales"):
        files.update({p.relative_to(STATIC).as_posix(): p.read_bytes() for p in public_files(STATIC / group)})
    pack_ref = "../../" + pack_path + "/"
    for name in ("device-scan.js", "score-conversion.js"):
        files[name] = files[name].replace(b"./scanner-pack/", pack_ref.encode())
    app = files["app.js"].decode()
    app = replace_once(app, "const capture = initCapture({", "const capture = initCapture({\n  scanLocal,")
    app = replace_once(app, "fetch('/example.json')", "fetch(new URL('./example.json', import.meta.url))")
    files["app.js"] = ("import { scanLocal } from './setup.js'\n" + app).encode()
    teacher = files["teacher.js"].decode()
    files["teacher.js"] = replace_once(teacher, "'/scales/' + key.id + '.svg'",
                                      "new URL('./scales/' + key.id + '.svg', import.meta.url)").encode()
    files["style.css"] = files["style.css"].replace(b"url('/", b"url('./") + (PHONE / "setup.css").read_bytes()
    files["setup.js"] = (PHONE / "setup.js").read_bytes()
    files["pack-info.js"] = (f"export const packRoot = '{pack_ref}'\nexport const packId = '{pack_id}'\n"
                             f"export const scannerFiles = {json.dumps(inventory, separators=(',', ':'))}\n").encode()
    template = (STATIC / "index.html").read_text(encoding="utf-8")
    template = template.split('    <script type="importmap">')[0]
    template = replace_once(template, '            <div class="viewfinder"',
                            (PHONE / "setup-panel.html").read_text(encoding="utf-8") + '\n            <div class="viewfinder"')
    template = replace_once(template, '<meta charset="utf-8" />', '<meta charset="utf-8" />\n'
                            '    <meta http-equiv="Content-Security-Policy" content="connect-src \'self\' data: blob:; '
                            'object-src \'none\'; form-action \'none\'; base-uri \'none\'" />')
    template += ('    <a class="phone-source" href="https://github.com/Kyoshi002/scorelens-phone">'
                 'Source code and licenses</a>\n    <script type="module" src="/app.js"></script>\n  </body>\n</html>\n')
    sw_template = (PHONE / "service-worker.js").read_text(encoding="utf-8")
    shell_id = digest((template + sw_template).encode() + b"".join(
        name.encode() + sha256(data).digest() for name, data in sorted(files.items())))[:16]
    app_path = 'app/' + shell_id + '/'
    for name, data in files.items():
        dest = out / app_path / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    template = template.replace('href="/manifest.webmanifest"', 'href="./manifest.webmanifest"')
    template = re.sub(r'(href|src)="/([^"?]+)(?:\?v=v\d+)?"', rf'\1="./{app_path}\2"', template)
    (out / "index.html").write_text(template, encoding="utf-8")
    manifest = json.loads((STATIC / "manifest.webmanifest").read_text(encoding="utf-8"))
    manifest.update(id="./", start_url="./", scope="./")
    for icon in manifest["icons"]:
        icon["src"] = "./" + app_path + icon["src"].lstrip("/")
    (out / "manifest.webmanifest").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    shell_files = ["index.html", "manifest.webmanifest"] + [app_path + name for name in files if not is_notice(Path(name))]
    sw = sw_template.replace("__SHELL_ID__", shell_id).replace("__PACK_ID__", pack_id)
    (out / "sw.js").write_text(sw.replace("__SHELL_FILES__", json.dumps(shell_files)), encoding="utf-8")
    (out / ".nojekyll").touch()
    # The installer verifies the published bytes. Preserve generated text verbatim on Windows.
    (out / ".gitattributes").write_text("* -text\n", encoding="ascii")
    shutil.copyfile(PHONE / "README.public.md", out / "README.md")
    shutil.copyfile(PHONE / "LICENSE", out / "LICENSE")

    # Offer the editable sources and deployment inputs only. The private host and user data
    # are not part of this distribution. Download scripts verify the pinned upstream binaries.
    source_dir = out / "source"
    source_dir.mkdir()
    source_files = [ROOT / "score.py", ROOT / "score_conversion.py", Path(__file__)]
    source_files += list((ROOT / "tools").glob("prepare*engine*.py")) + list((ROOT / "tools").glob("*phone*engine*.py"))
    source_files += [ROOT / "tools/prepare_pdf_assets.py", ROOT / "tools/stage_score_converter.py"]
    source_files += public_files(PHONE) + [STATIC / name for name in (*SHELL, "manifest.webmanifest", "index.html")]
    source_files += [STATIC / "morning-walk.musicxml"]
    for group in ("scales", "fonts"):
        source_files.extend(public_files(STATIC / group))
    source_files.extend(p for p in assets if not is_notice(p) and
                        (p.name in {"omr-worker.js", "score-conversion-worker.js"} or p.suffix == ".py"))
    source_files.extend(p for p in assets if is_notice(p))
    with ZipFile(source_dir / "scorelens-source.zip", "w", ZIP_DEFLATED) as archive:
        for p in sorted(set(source_files)):
            archive.write(p, p.relative_to(ROOT))
    print(f"Phone edition {shell_id}: {len(inventory)} scanner files, {sum(f['bytes'] for f in inventory):,} bytes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    build(parser.parse_args().output.resolve())
