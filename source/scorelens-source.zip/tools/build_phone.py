"""Build the static, subpath-safe phone distribution from staged scanner assets."""

import argparse
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import shutil
from zipfile import ZipFile, ZIP_DEFLATED

from prepare_phone_engine import MODELS, ORT, ORT_FILES, PARTSONG_FILES
from stage_score_converter import RUNTIME as PYODIDE_FILES
from stage_score_converter import SOURCE as CONVERTER_SOURCES


ROOT = Path(__file__).resolve().parents[1]
STATIC = ROOT / "static"
PHONE = ROOT / "phone"
SHELL = (
    "app.js", "capture.js", "device-scan.js", "example.json", "follow.css", "follow.js",
    "grain.png", "icon-192.png", "icon-512.png", "icons.js", "key-reading.js",
    "keys.js", "listen.js", "morning-walk.png", "pdf-library.js", "practice.js",
    "score-conversion.js", "style.css", "teacher.js",
)
PHONE_SOURCES = ("LICENSE", "README.public.md", "service-worker.js", "setup-panel.html", "setup.css", "setup.js")
FONTS = ("DMSerifText-LICENSE.txt", "DMSerifText.ttf", "InstrumentSans-LICENSE.txt", "InstrumentSans.ttf")
ENGINE_NOTICES = (
    "LICENSE-AGPL-3.0.txt", "source/NOTICE.txt", "source/homr-0.7.1-source.zip",
    "source/homr-rs-source.zip", "source/onnxruntime-LICENSE", "source/onnxruntime-ThirdPartyNotices.txt",
    "source/scorelens-omr-worker.zip",
)
PYODIDE_ASSETS = tuple("pyodide/" + p for p in (*PYODIDE_FILES, "LICENSE", "CPYTHON-LICENSE"))
# Aggregate digests of sorted path and SHA-256 lines from the pinned stage scripts.
PDF_COUNT = 202
PDF_DIGEST = "62a3c8377eceb8917e4dfad72f2568e5c3f3e1e9d84435b485416e0ae41ea40f"
PYODIDE_DIGEST = "2129c9d6c85eae0c46ecff620fbb8e1dcfff9ff97845e2f3281b178a7a4de4f4"


def public_files(directory):
    return sorted(p for p in directory.rglob("*") if p.is_file()
                  and not any(s.startswith(".") or s == "__pycache__" for s in p.relative_to(directory).parts))


def digest(data):
    return sha256(data).hexdigest()


def file_hash(path):
    with path.open("rb") as stream:
        return file_digest(stream, "sha256").hexdigest()


def required_files(directory, paths):
    files = [directory / path for path in sorted(paths)]
    for file in files:
        if not file.is_file() or not file.stat().st_size:
            raise ValueError(f"Missing or empty release asset: {file.relative_to(ROOT)}")
    return files


def aggregate(directory, files):
    paths = sorted((p.relative_to(directory).as_posix(), p) for p in files)
    lines = [f"{name} {file_hash(path)}" for name, path in paths]
    return digest("\n".join(lines).encode())


def scanner_assets(pack):
    engine, pdf, converter = (pack / name for name in ("engine", "pdf", "converter"))
    engine_paths = (PARTSONG_FILES | {f"lib/onnxruntime-web@{ORT}/dist/{name}" for name in ORT_FILES}
                    | {f"models/{name}.onnx" for name in MODELS})
    manifest_file, = required_files(engine, ("runtime-assets.json",))
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    if len(manifest) != len(engine_paths) or {item["path"] for item in manifest} != engine_paths:
        raise ValueError("The browser OMR inventory is incomplete. Run tools/prepare_phone_engine.py.")
    for item in manifest:
        file, = required_files(engine, (item["path"],))
        if file.stat().st_size != item["bytes"] or file_hash(file) != item["sha256"]:
            raise ValueError(f"Browser OMR inventory mismatch for {item['path']}. Run tools/prepare_phone_engine.py.")
    engine_files = required_files(engine, engine_paths | set(ENGINE_NOTICES))

    pdf_files = public_files(pdf)
    if len(pdf_files) != PDF_COUNT or aggregate(pdf, pdf_files) != PDF_DIGEST:
        raise ValueError("The PDF.js assets are incomplete or differ from the pinned release. Run tools/prepare_pdf_assets.py.")

    python_assets = required_files(converter, PYODIDE_ASSETS)
    if aggregate(converter, python_assets) != PYODIDE_DIGEST:
        raise ValueError("The Pyodide assets differ from the pinned release. Run tools/stage_score_converter.py.")
    conversion_files = required_files(converter, (*CONVERTER_SOURCES, "score-conversion-worker.js", "THIRD-PARTY.txt"))
    for source in CONVERTER_SOURCES:
        if (converter / source).read_bytes() != (ROOT / source).read_bytes():
            raise ValueError(f"Stale browser score source {source}. Run tools/stage_score_converter.py.")
    return sorted(engine_files + pdf_files + python_assets + conversion_files,
                  key=lambda p: p.relative_to(pack).as_posix())


def replace_once(text, before, after):
    if text.count(before) != 1:
        raise ValueError(f"Phone template does not match: {before}")
    return text.replace(before, after)


def is_notice(path):
    return ("LICENSE" in path.name.upper() or "NOTICE" in path.name.upper() or
            "THIRD-PARTY" in path.name.upper() or path.suffix.lower() == ".md")


def build(out):
    # Always build into a fresh directory so a previous deployment cannot leak into it.
    if out.exists() and any(out.iterdir()):
        raise ValueError("Choose an empty build directory.")
    pack = STATIC / "scanner-pack"
    assets = scanner_assets(pack)
    fonts = required_files(STATIC / "fonts", FONTS)
    index = STATIC / "scales/index.json"
    scale_names = json.loads(index.read_text(encoding="utf-8"))
    if len(set(scale_names)) != 30 or any(not re.fullmatch(r"[a-g](?:-flat|-sharp)?-(?:major|minor)\.svg", n) for n in scale_names):
        raise ValueError("The phone edition requires the 30 catalog scale engravings.")
    scales = required_files(STATIC / "scales", scale_names)
    out.mkdir(parents=True, exist_ok=True)
    inventory = [dict(path=p.relative_to(pack).as_posix(), bytes=p.stat().st_size,
                      sha256=file_hash(p)) for p in assets
                 if not is_notice(p) and "source" not in p.relative_to(pack).parts]
    pack_id = digest(json.dumps(inventory).encode())[:16]
    pack_path = "packs/" + pack_id
    for p in assets:
        dest = out / pack_path / p.relative_to(pack)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)

    files = {name: (STATIC / name).read_bytes() for name in SHELL}
    files.update({p.relative_to(STATIC).as_posix(): p.read_bytes() for p in fonts + scales})
    pack_ref = "../../" + pack_path + "/"
    for name in ("device-scan.js", "score-conversion.js"):
        files[name] = files[name].replace(b"./scanner-pack/", pack_ref.encode())
    app = files["app.js"].decode()
    app = replace_once(app, "const capture = initCapture({", "const capture = initCapture({\n  scanLocal,")
    app = replace_once(app, "fetch('/example.json')", "fetch(new URL('./example.json', import.meta.url))")
    files["app.js"] = ("import { scanLocal } from './setup.js'\n" + app).encode()
    teacher = files["teacher.js"].decode()
    files["teacher.js"] = replace_once(teacher, "'/scales/' + key.id + '.svg'",
                                      "new URL('./scales/' + key.id + '.svg', import.meta.url)").encode()
    files["style.css"] = files["style.css"].replace(b"url('/", b"url('./") + (PHONE / "setup.css").read_bytes()
    files["setup.js"] = (PHONE / "setup.js").read_bytes()
    files["pack-info.js"] = (f"export const packRoot = '{pack_ref}'\nexport const packId = '{pack_id}'\n"
                             f"export const scannerFiles = {json.dumps(inventory, separators=(',', ':'))}\n").encode()
    template = (STATIC / "index.html").read_text(encoding="utf-8")
    template = template.split('    <script type="importmap">')[0]
    template = replace_once(template, '            <div class="viewfinder"',
                            (PHONE / "setup-panel.html").read_text(encoding="utf-8") + '\n            <div class="viewfinder"')
    template = replace_once(template, '<meta charset="utf-8" />', '<meta charset="utf-8" />\n'
                            '    <meta http-equiv="Content-Security-Policy" content="connect-src \'self\' data: blob:; '
                            'object-src \'none\'; form-action \'none\'; base-uri \'none\'" />')
    template += ('    <a class="phone-source" href="https://github.com/Kyoshi002/scorelens-phone">'
                 'Source code and licenses</a>\n    <script type="module" src="/app.js"></script>\n  </body>\n</html>\n')
    sw_template = (PHONE / "service-worker.js").read_text(encoding="utf-8")
    manifest_source = (STATIC / "manifest.webmanifest").read_bytes()
    shell_id = digest((template + sw_template).encode() + manifest_source + b"".join(
        name.encode() + sha256(data).digest() for name, data in sorted(files.items())))[:16]
    app_path = 'app/' + shell_id + '/'
    for name, data in files.items():
        dest = out / app_path / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    template = template.replace('href="/manifest.webmanifest"', 'href="./manifest.webmanifest"')
    template = re.sub(r'(href|src)="/([^"?]+)(?:\?v=v\d+)?"', rf'\1="./{app_path}\2"', template)
    (out / "index.html").write_text(template, encoding="utf-8")
    manifest = json.loads(manifest_source)
    manifest.update(id="./", start_url="./", scope="./")
    for icon in manifest["icons"]:
        icon["src"] = "./" + app_path + icon["src"].lstrip("/")
    (out / "manifest.webmanifest").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    shell_files = ["index.html", "manifest.webmanifest"] + [app_path + name for name in files if not is_notice(Path(name))]
    sw = sw_template.replace("__SHELL_ID__", shell_id)
    (out / "sw.js").write_text(sw.replace("__SHELL_FILES__", json.dumps(shell_files)), encoding="utf-8")
    (out / ".nojekyll").touch()
    # The installer verifies the published bytes. Preserve generated text verbatim on Windows.
    (out / ".gitattributes").write_text("* -text\n", encoding="ascii")
    shutil.copyfile(PHONE / "README.public.md", out / "README.md")
    shutil.copyfile(PHONE / "LICENSE", out / "LICENSE")

    # Offer the editable sources and deployment inputs only. The private host and user data
    # are not part of this distribution. Download scripts verify the pinned upstream binaries.
    source_dir = out / "source"
    source_dir.mkdir()
    source_files = [ROOT / "score.py", ROOT / "score_conversion.py", Path(__file__)]
    source_files += [ROOT / "tools/prepare_phone_engine.py"]
    source_files += [ROOT / "tools/prepare_pdf_assets.py", ROOT / "tools/stage_score_converter.py"]
    source_files += required_files(PHONE, PHONE_SOURCES) + [STATIC / name for name in (*SHELL, "manifest.webmanifest", "index.html")]
    source_files += [STATIC / "morning-walk.musicxml"]
    source_files.extend(fonts + scales + [index])
    source_files.extend(p for p in assets if not is_notice(p) and
                        (p.name in {"omr-worker.js", "score-conversion-worker.js"} or p.suffix == ".py"))
    source_files.extend(p for p in assets if is_notice(p))
    with ZipFile(source_dir / "scorelens-source.zip", "w", ZIP_DEFLATED) as archive:
        for p in sorted(set(source_files), key=lambda p: p.relative_to(ROOT).as_posix()):
            archive.write(p, p.relative_to(ROOT))
    print(f"Phone edition {shell_id}: {len(inventory)} scanner files, {sum(f['bytes'] for f in inventory):,} bytes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    build(parser.parse_args().output.resolve())
