"""Stage the pinned stdlib-only Pyodide runtime and canonical ScoreLens source."""

import argparse
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from shutil import copyfile
import tarfile
from urllib.request import urlopen


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "static/scanner-pack/converter"
VERSION = "0.27.8"
ARCHIVE = f"https://github.com/pyodide/pyodide/releases/download/{VERSION}/pyodide-core-{VERSION}.tar.bz2"
ARCHIVE_HASH = "b7ed9d0eb44499578403d9c67935510f76c4534de3cac2fef03da4ac274ac294"
LICENSE = f"https://raw.githubusercontent.com/pyodide/pyodide/{VERSION}/LICENSE"
LICENSE_HASH = "1f256ecad192880510e84ad60474eab7589218784b9a50bc7ceee34c2b91f1d5"
CPYTHON_LICENSE = "https://raw.githubusercontent.com/python/cpython/v3.12.7/LICENSE"
CPYTHON_LICENSE_HASH = "3b2f81fe21d181c499c59a256c8e1968455d6689d269aa85373bfb6af41da3bf"
RUNTIME = ("pyodide.mjs", "pyodide.asm.js", "pyodide.asm.wasm", "pyodide-lock.json", "python_stdlib.zip")
SOURCE = ("score.py", "score_conversion.py")


def verified_bytes(url, digest, path=None):
    if path is None:
        with urlopen(url, timeout=60) as response:
            data = response.read()
    else:
        data = path.read_bytes()
    if sha256(data).hexdigest() != digest:
        raise SystemExit(f"Checksum mismatch for {url.rsplit('/', 1)[-1]}")
    return data


def stage(output=OUTPUT, *, archive=None, license_path=None, cpython_license=None):
    runtime = output / "pyodide"
    runtime.mkdir(parents=True, exist_ok=True)
    core = verified_bytes(ARCHIVE, ARCHIVE_HASH, archive)
    license_text = verified_bytes(LICENSE, LICENSE_HASH, license_path)
    cpython_license_text = verified_bytes(CPYTHON_LICENSE, CPYTHON_LICENSE_HASH, cpython_license)
    with tarfile.open(fileobj=BytesIO(core), mode="r:bz2") as files:
        for name in RUNTIME:
            with files.extractfile(f"pyodide/{name}") as source:
                (runtime / name).write_bytes(source.read())
    (runtime / "LICENSE").write_bytes(license_text)
    (runtime / "CPYTHON-LICENSE").write_bytes(cpython_license_text)
    for name in SOURCE:
        copyfile(ROOT / name, output / name)
    size = sum((runtime / name).stat().st_size for name in RUNTIME)
    print(f"Prepared Pyodide {VERSION} score converter ({size:,} bytes of runtime assets).")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive", type=Path, help="Use a local copy of the pinned upstream core archive.")
    parser.add_argument("--license", type=Path, help="Use a local copy of the pinned upstream license.")
    parser.add_argument("--cpython-license", type=Path, help="Use a local copy of the CPython license.")
    options = parser.parse_args()
    stage(archive=options.archive, license_path=options.license, cpython_license=options.cpython_license)
