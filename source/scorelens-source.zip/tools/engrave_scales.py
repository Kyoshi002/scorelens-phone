"""Regenerate the offline scale figures with Node.js and Verovio 6.4.1.

Run from the project directory: uv run --with verovio==6.4.1 tools/engrave_scales.py
Music engraving uses Verovio (LGPLv3), with its Leipzig symbol outlines (SIL OFL 1.1).
https://book.verovio.org/introduction/licensing.html
https://book.verovio.org/advanced-topics/smufl.html
"""

import json
import re
import subprocess
from pathlib import Path
from xml.etree.ElementTree import Element, SubElement, tostring

import verovio


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "static" / "scales"
PITCH = re.compile(r"([A-G])([♯♭]?)(\d+)")
ACCIDENTAL = {"♯": "1", "♭": "-1"}
ASCENDING_MEASURES = 2
OPTIONS = {
    "adjustPageHeight": True,
    "adjustPageWidth": True,
    "breaks": "none",
    "fingeringScale": 1.0,
    "footer": "none",
    "header": "none",
    "pageWidth": 920,
    "pageMarginLeft": 24,
    "pageMarginRight": 24,
    "pageMarginTop": 24,
    "pageMarginBottom": 24,
    "scale": 100,
    "smuflTextFont": "none",
    "spacingLinear": 0.18,
    "spacingNonLinear": 0.55,
    "svgCss": "svg { color: #18372a; } g.keySig g.keyAccid { color: #326549; fill: #326549; }",
    "svgViewBox": True,
    "xmlIdSeed": 1,
}


def add(parent, tag, value=None, **attributes):
    element = SubElement(parent, tag, attributes)
    if value is not None:
        element.text = str(value)
    return element


def catalog():
    result = subprocess.run(
        [
            "node", "--input-type=module", "-e",
            """
            import { keys, makeScaleScore } from './static/keys.js'
            process.stdout.write(JSON.stringify(keys.map(({id, fifths, mode}) => ({
              id, fifths, mode, score: makeScaleScore(id, 'both')
            }))))
            """,
        ],
        cwd=ROOT,
        check=True,
        capture_output=True,
    )
    return json.loads(result.stdout)


def append_note(measure, event, hand, staff):
    source = next(note for note in event["notes"] if note["hand"] == hand)
    step, accidental, octave = PITCH.fullmatch(source["name"]).groups()
    note = add(measure, "note")
    pitch = add(note, "pitch")
    add(pitch, "step", step)
    if accidental:
        add(pitch, "alter", ACCIDENTAL[accidental])
    add(pitch, "octave", octave)
    add(note, "duration", int(source["duration"]))
    add(note, "voice", staff)
    add(note, "type", "quarter")
    add(note, "staff", staff)
    technique = add(add(note, "notations"), "technical")
    add(technique, "fingering", source["finger"], placement="above" if staff == 1 else "below")


def musicxml(lesson):
    root = Element("score-partwise", version="4.0")
    part_list = add(root, "part-list")
    add(add(part_list, "score-part", id="P1"), "part-name", "Piano", **{"print-object": "no"})
    part = add(root, "part", id="P1")
    for index, source in enumerate(lesson["score"]["measures"][:ASCENDING_MEASURES]):
        measure = add(part, "measure", number=source["number"])
        if index == 0:
            attributes = add(measure, "attributes")
            add(attributes, "divisions", 1)
            key = add(attributes, "key")
            add(key, "fifths", lesson["fifths"])
            add(key, "mode", lesson["mode"])
            time = add(attributes, "time")
            add(time, "beats", 4)
            add(time, "beat-type", 4)
            add(attributes, "staves", 2)
            add(attributes, "part-symbol", "brace")
            for staff, sign, line in ((1, "G", 2), (2, "F", 4)):
                clef = add(attributes, "clef", number=str(staff))
                add(clef, "sign", sign)
                add(clef, "line", line)
        for event in source["events"]:
            append_note(measure, event, "right", 1)
        add(add(measure, "backup"), "duration", int(source["duration"]))
        for event in source["events"]:
            append_note(measure, event, "left", 2)
        if index == ASCENDING_MEASURES - 1:
            add(add(measure, "barline", location="right"), "bar-style", "light-heavy")
    return tostring(root, encoding="unicode")


def main():
    lessons = catalog()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    toolkit = verovio.toolkit()
    toolkit.setOptions(OPTIONS)
    filenames = []
    for lesson in lessons:
        if not toolkit.loadData(musicxml(lesson)) or toolkit.getPageCount() != 1:
            raise RuntimeError(f"Could not engrave {lesson['id']} on one page")
        filename = f"{lesson['id']}.svg"
        svg = toolkit.renderToSVG(1)
        (OUTPUT / filename).write_text(svg, encoding="utf-8", newline="\n")
        filenames.append(filename)
    (OUTPUT / "index.json").write_text(
        json.dumps(filenames, indent=2) + "\n", encoding="utf-8", newline="\n"
    )
    print(f"Engraved {len(lessons)} scales in {OUTPUT}")


if __name__ == "__main__":
    main()
