"""Generate offline rhythm examples with Node.js and the pinned Verovio 6.4.1.

Run from the project directory:
  uv run --with verovio==6.4.1 tools/engrave_rhythm.py
Verovio is LGPLv3 and its Leipzig symbol outlines are SIL OFL 1.1:
https://book.verovio.org/introduction/licensing.html
"""

import json
from pathlib import Path
import re
import subprocess
from xml.etree.ElementTree import Element, tostring

import verovio

from engrave_scales import OPTIONS, add


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "static" / "rhythm-notation"
DURATION_NAMES = {4: "eighth", 6: "eighth", 12: "quarter", 18: "quarter", 24: "half"}
PITCH = re.compile(r"([A-G])([#b]?)(\d+)")


def beams(bar, pulse):
    groups = {}
    offset = 0
    for index, event in enumerate(bar):
        if event["ticks"] in (4, 6) and "pitch" in event:
            groups.setdefault(offset // pulse, []).append(index)
        offset += event["ticks"]
    return {
        index: "begin" if member == 0 else "end" if member == len(group) - 1 else "continue"
        for group in groups.values()
        if len(group) > 1 and group[-1] - group[0] == len(group) - 1
        for member, index in enumerate(group)
    }


def write_event(measure, source, beam):
    if dynamics := source.get("dynamic"):
        direction = add(measure, "direction", placement="below")
        add(add(add(direction, "direction-type"), "dynamics"), dynamics)
    event = add(measure, "note")
    if name := source.get("pitch"):
        step, accidental, octave = PITCH.fullmatch(name).groups()
        pitch = add(event, "pitch")
        add(pitch, "step", step)
        if accidental:
            add(pitch, "alter", 1 if accidental == "#" else -1)
        add(pitch, "octave", octave)
    else:
        add(event, "rest")
    add(event, "duration", source["ticks"])
    if tie := source.get("tie"):
        add(event, "tie", type=tie)
    add(event, "voice", 1)
    add(event, "type", DURATION_NAMES[source["ticks"]])
    if source["ticks"] == 18:
        add(event, "dot")
    if accidental := source.get("accidental"):
        add(event, "accidental", accidental)
    if triplet := source.get("triplet"):
        modification = add(event, "time-modification")
        add(modification, "actual-notes", 3)
        add(modification, "normal-notes", 2)
    if beam:
        add(event, "beam", beam, number="1")
    articulation = source.get("articulation")
    if tie or articulation or triplet in ("start", "stop"):
        markings = add(event, "notations")
        if tie:
            add(markings, "tied", type=tie)
        if articulation:
            add(add(markings, "articulations"), articulation)
        if triplet == "start":
            add(markings, "tuplet", type="start", bracket="yes", **{"show-number": "actual"})
        elif triplet == "stop":
            add(markings, "tuplet", type="stop")


def musicxml(lesson):
    root = Element("score-partwise", version="4.0")
    parts = add(root, "part-list")
    add(add(parts, "score-part", id="P1"), "part-name", "Piano", **{"print-object": "no"})
    part = add(root, "part", id="P1")
    beats, denominator = lesson["meter"]
    for index, bar in enumerate(lesson["bars"]):
        measure = add(part, "measure", number=str(index + 1))
        if index == 0:
            attributes = add(measure, "attributes")
            add(attributes, "divisions", 12)
            add(add(attributes, "key"), "fifths", 0)
            time = add(attributes, "time")
            add(time, "beats", beats)
            add(time, "beat-type", denominator)
            clef = add(attributes, "clef")
            add(clef, "sign", "G")
            add(clef, "line", 2)
        groups = beams(bar, lesson["pulse"])
        for event_index, event in enumerate(bar):
            write_event(measure, event, groups.get(event_index))
        if index == len(lesson["bars"]) - 1:
            add(add(measure, "barline", location="right"), "bar-style", "light-heavy")
    return tostring(root, encoding="unicode")


def main():
    catalog = subprocess.run(
        ["node", "--input-type=module", "-e",
         "import { rhythmLessons } from './static/rhythm-study.js'; "
         "process.stdout.write(JSON.stringify(rhythmLessons));"],
        cwd=ROOT,
        check=True,
        capture_output=True,
    )
    lessons = json.loads(catalog.stdout)
    toolkit = verovio.toolkit()
    toolkit.setOptions({**OPTIONS, "pageMarginBottom": 36, "pageMarginTop": 22})
    OUTPUT.mkdir(parents=True, exist_ok=True)
    files = []
    for lesson in lessons:
        if not toolkit.loadData(musicxml(lesson)) or toolkit.getPageCount() != 1:
            raise RuntimeError("Cannot engrave " + lesson["id"])
        filename = lesson["id"] + ".svg"
        (OUTPUT / filename).write_text(toolkit.renderToSVG(1), encoding="utf-8", newline="\n")
        files.append(filename)
    (OUTPUT / "index.json").write_text(json.dumps(files, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(f"Engraved {len(files)} rhythm examples.")


if __name__ == "__main__":
    main()
