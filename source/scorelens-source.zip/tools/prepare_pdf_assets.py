"""Install the pinned browser PDF renderer and its fonts and image decoders."""

import base64
import hashlib
from io import BytesIO
from pathlib import Path
import tarfile
from urllib.request import urlopen


VERSION = "6.5.438"
SHA512 = (
    "vg8Pw1x+AFKy4AMDvhuWl5cOYV8d698UoEANoFFhc79hqXDnZQqnOXoxw3HG907WHOg1JYOvLhP756boddFxpA=="
)
ARCHIVE = f"https://registry.npmjs.org/pdfjs-dist/-/pdfjs-dist-{VERSION}.tgz"
OUTPUT = Path(__file__).resolve().parents[1] / "static/scanner-pack/pdf"
BUILDS = {"pdf.min.mjs", "pdf.worker.min.mjs", "pdf.renderer.min.mjs"}
ASSET_DIRS = {"cmaps", "iccs", "standard_fonts", "wasm"}


def asset_path(name):
    parts = name.split("/")
    if name == "package/LICENSE":
        return Path("LICENSE")
    if len(parts) == 4 and parts[:3] == ["package", "legacy", "build"] and parts[3] in BUILDS:
        return Path(parts[3])
    if len(parts) == 3 and parts[0] == "package" and parts[1] in ASSET_DIRS and parts[2] not in {".", ".."}:
        # The canvas renderer does not enable PDF JavaScript or the viewer sandbox.
        if parts[1] != "wasm" or "quickjs" not in parts[2].lower():
            return Path(*parts[1:])
    return None


def main():
    with urlopen(ARCHIVE, timeout=60) as response:
        archive = response.read()
    actual = base64.b64encode(hashlib.sha512(archive).digest()).decode("ascii")
    if actual != SHA512:
        raise SystemExit("PDF.js archive checksum mismatch")

    count = size = 0
    with tarfile.open(fileobj=BytesIO(archive), mode="r:gz") as tar:
        for member in tar:
            relative = asset_path(member.name)
            if relative is None or not member.isfile():
                continue
            destination = OUTPUT / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(member) as source:
                destination.write_bytes(source.read())
            count += 1
            size += member.size
    print(f"Prepared PDF.js {VERSION}: {count} assets, {size:,} bytes.")


if __name__ == "__main__":
    main()
