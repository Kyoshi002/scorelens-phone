const shellCache = 'scorelens-phone-shell-__SHELL_ID__'
const packCache = 'scorelens-phone-pack-__PACK_ID__'
const scope = self.registration.scope
const shellFiles = __SHELL_FILES__.map(path => new URL(path, scope).href)
const packBase = new URL('packs/__PACK_ID__/', scope).href

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(shellCache)
    await cache.addAll(shellFiles.map(url => new Request(url, { cache: 'reload' })))
  })())
})
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const name of await caches.keys()) {
      if (name.startsWith('scorelens-phone-shell-') && name !== shellCache) await caches.delete(name)
    }
    await self.clients.claim()
  })())
})
self.addEventListener('fetch', event => {
  const request = event.request
  if (request.method !== 'GET' || !request.url.startsWith(scope)) return
  if (request.url.startsWith(packBase)) {
    event.respondWith((async () => (await caches.match(request, { cacheName: packCache, ignoreSearch: true })) || fetch(request))())
  } else if (request.mode === 'navigate' && new URL(request.url).pathname === new URL(scope).pathname) {
    event.respondWith((async () => (await caches.match(new URL('index.html', scope), { cacheName: shellCache })) || fetch(request))())
  } else if (shellFiles.includes(request.url)) {
    event.respondWith((async () => (await caches.match(request, { cacheName: shellCache })) || fetch(request))())
  }
})
